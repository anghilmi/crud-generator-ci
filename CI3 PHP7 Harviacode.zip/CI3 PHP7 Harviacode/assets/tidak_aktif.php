<?php

 echo $this->Data_siswa_model->tidak_aktif();
// echo "5";

		// $CI =& get_instance();

		// $CI->db->select('id');

  //       $CI->db->from('data_mhs');
  //       $CI->db->where('status_siswa','Tidak Aktif');
  //       return $CI->db->count_all_results();         
        //$query=$CI->db->get();

        //$record=$query->row();

        //return $record->$kolom;

?>